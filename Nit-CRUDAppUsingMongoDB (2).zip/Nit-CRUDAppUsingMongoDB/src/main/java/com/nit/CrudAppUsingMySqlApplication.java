package com.nit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudAppUsingMySqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudAppUsingMySqlApplication.class, args);
	}

}
