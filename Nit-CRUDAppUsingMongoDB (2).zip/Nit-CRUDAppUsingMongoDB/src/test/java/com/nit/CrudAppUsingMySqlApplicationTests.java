package com.nit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudAppUsingMySqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
