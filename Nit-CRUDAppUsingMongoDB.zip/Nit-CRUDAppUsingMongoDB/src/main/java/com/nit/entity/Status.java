/*package com.nit.entity;

import org.springframework.data.mongodb.core.mapping.Field;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Status {
  
	@Field(name="student_active")
	private Boolean active;
	@Field(name="student_In_Active")
	private Boolean inActive;
	@Field(name="student_delete")
	private Boolean isDelete;
	
	
	/private String active1;//null
	private String Inactiveactive;
}

// active incative delete
*/